<?php
class Zend_View_Helper_MyHelper1 extends Zend_View_Helper_Abstract

{

	public function myHelper1($myParam1)

	{

		$html = 'gfhgfh';

		// some logic that fills in $html.

		return $html;

	}

}