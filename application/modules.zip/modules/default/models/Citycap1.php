<?php

class Default_Model_Citycap1 extends Core_Db_Table_Abstract 
{

    public $_name = "city_cap_1";

    public function __construct() 
    {
        parent::__construct();
    }

    

}

?>