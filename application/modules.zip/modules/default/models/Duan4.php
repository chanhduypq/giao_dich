<?php

class Default_Model_Duan4 extends Core_Db_Table_Abstract 
{

    public $_name = "du_an_cap_4";

    public function __construct() 
    {
        parent::__construct();
    }

    

}

?>