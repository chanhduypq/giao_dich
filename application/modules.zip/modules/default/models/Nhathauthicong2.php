<?php

class Default_Model_Nhathauthicong2 extends Core_Db_Table_Abstract 
{

    public $_name = "nha_thau_thi_cong_cap_2";

    public function __construct() 
    {
        parent::__construct();
    }

    

}

?>