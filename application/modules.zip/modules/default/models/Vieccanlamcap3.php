<?php

class Default_Model_Vieccanlamcap3 extends Core_Db_Table_Abstract 
{

    public $_name = "viec_can_lam_cap_3";

    public function __construct() 
    {
        parent::__construct();
    }

    

}

?>