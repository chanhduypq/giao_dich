<?php

class Default_Model_Citycap2 extends Core_Db_Table_Abstract 
{

    public $_name = "city_cap_2";

    public function __construct() 
    {
        parent::__construct();
    }

    

}

?>