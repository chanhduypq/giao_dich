<?php

class Default_Model_Citycap3 extends Core_Db_Table_Abstract 
{

    public $_name = "city_cap_3";

    public function __construct() 
    {
        parent::__construct();
    }

    

}

?>