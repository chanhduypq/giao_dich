<?php
class WsClass_Exception extends Zend_Exception {}
