<?php

class Core_Db_Table extends Core_Db_Table_Abstract
{	    
}