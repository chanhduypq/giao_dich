<?php

require_once 'Core/Form/Element/Xhtml.php';


class Core_Form_Element_Image extends Core_Form_Element_Xhtml
{
    /**
     * What view helper to use when using view helper decorator
     * @var string
     */
    public $helper = 'formImage';

    /**
     * Image source
     * @var string
     */
    public $src;

    /**
     * Image value
     * @var mixed
     */
    protected $_imageValue;

    /**
     * Load default decorators
     *
     * @return Core_Form_Element_Image
     */
    public function loadDefaultDecorators()
    {
        if ($this->loadDefaultDecoratorsIsDisabled()) {
            return $this;
        }

        $decorators = $this->getDecorators();
        if (empty($decorators)) {
            $this->addDecorator('Tooltip')
                 ->addDecorator('Image')
                 ->addDecorator('Errors')
                 ->addDecorator('HtmlTag', array('tag' => 'dd'))
                 ->addDecorator('Label', array('tag' => 'dt'));
        }
        return $this;
    }

    /**
     * Set image path
     *
     * @param  string $path
     * @return Core_Form_Element_Image
     */
    public function setImage($path)
    {
        $this->src = (string) $path;
        return $this;
    }

    /**
     * Get image path
     *
     * @return string
     */
    public function getImage()
    {
        return $this->src;
    }

    /**
     * Set image value to use when submitted
     *
     * @param  mixed $value
     * @return Core_Form_Element_Image
     */
    public function setImageValue($value)
    {
        $this->_imageValue = $value;
        return $this;
    }

    /**
     * Get image value to use when submitted
     *
     * @return mixed
     */
    public function getImageValue()
    {
        return $this->_imageValue;
    }

    /**
     * Was this element used to submit the form?
     *
     * @return bool
     */
    public function isChecked()
    {
        $imageValue = $this->getImageValue();
        return ((null !== $imageValue) && ($this->getValue() == $imageValue));
    }

}
